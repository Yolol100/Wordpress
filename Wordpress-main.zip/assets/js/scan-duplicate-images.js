document.addEventListener('DOMContentLoaded', () => {
    const scanForm = document.querySelector('.mim-scan-page-form');
    if (scanForm) {
        scanForm.addEventListener('submit', (e) => {
            const intro = document.getElementById('mim-scan-intro');
            if (intro) {
                intro.style.display = 'none';
            }
        });
    }
});