<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class ACF_Export_Import_Admin {
    private ACF_Exporter $exporter;

    public function __construct() {
        $this->exporter = new ACF_Exporter();
        add_action( 'admin_menu', [ $this, 'add_import_page' ] );
        add_action( 'admin_post_acf_import_csv', [ $this, 'process_import' ] );
    }

    /**
     * Voeg de importpagina toe aan het admin-menu.
     */
    public function add_import_page(): void {
        add_submenu_page(
            'export-acf-csv',
            __( 'Import', 'export-acf-csv' ),
            __( 'Import', 'export-acf-csv' ),
            'manage_options',
            'export-acf-csv-import',
            [ $this, 'import_page_html' ]
        );
    }

    /**
     * Render de importpagina via een templatebestand.
     */
    public static function render_import_page(): void {
        mim_load_template( 'import-export/import-page-csv.php' );
    }

    /**
     * Toon de HTML van de importpagina.
     */
    public function import_page_html(): void {
        self::render_import_page();
    }

    /**
     * Verwerk de import van het CSV-bestand.
     */
    public function process_import(): void {
        if (
            ! current_user_can( 'manage_options' ) ||
            ! isset( $_POST['export_update_acf_csv_nonce'] ) ||
            ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['export_update_acf_csv_nonce'] ) ), 'export_update_acf_csv_action' )
        ) {
            wp_die( __( 'Toegang geweigerd of ongeldig nonce.', 'export-acf-csv' ) );
        }

        if (
            empty( $_FILES['csv_file']['tmp_name'] ) ||
            $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK
        ) {
            wp_die( __( 'Fout bij het uploaden van het CSV-bestand.', 'export-acf-csv' ) );
        }

        $file = $_FILES['csv_file']['tmp_name'];

        $this->exporter->import_from_csv( $file );

        wp_safe_redirect(
            add_query_arg( 'acf_import_success', 1, admin_url( 'admin.php?page=export-acf-csv-import' ) )
        );
        exit;
    }
}