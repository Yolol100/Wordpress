<?php
declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class ACF_Export_Page_Admin {
    public function __construct() {
        error_log('[ACF_Export_Page_Admin] Constructor gestart.');
        // Zorg dat de actie exact overeenkomt met de waarde in het formulier (hidden input "action" = "create_multiple_pages").
        add_action( 'admin_post_create_multiple_pages', [ $this, 'create_multiple_pages' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
    }

    /**
     * Voeg de benodigde scripts en stijlen toe aan de adminpagina.
     *
     * Let op: De hook-naam moet exact overeenkomen met de pagina waar deze assets nodig zijn.
     */
    public function enqueue_admin_assets( string $hook ): void {
        error_log('[ACF_Export_Page_Admin] enqueue_admin_assets() aangeroepen, hook: ' . $hook);
        if ( 'export_page_export-acf-csv-pagina' === $hook ) {
            wp_enqueue_style(
                'export-acf-csv-admin-css',
                EXPORT_ACF_CSV_PLUGIN_URL . 'assets/css/export-acf-csv-admin.css',
                [],
                EXPORT_ACF_CSV_VERSION,
                'all'
            );

            wp_enqueue_script(
                'export-acf-csv-admin-js',
                EXPORT_ACF_CSV_PLUGIN_URL . 'assets/js/export-acf-csv-admin.js',
                [ 'jquery' ],
                EXPORT_ACF_CSV_VERSION,
                true
            );

            wp_localize_script(
                'export-acf-csv-admin-js',
                'ajax_object',
                [
                    'ajax_url'   => admin_url( 'admin-ajax.php' ),
                    'ajax_nonce' => wp_create_nonce( 'create_pages_nonce' ),
                ]
            );
        }
    }

    /**
     * Laadt de pagina voor het aanmaken van meerdere pagina's via een templatebestand.
     */
    public function pagina_submenu_html(): void {
        error_log('[ACF_Export_Page_Admin] pagina_submenu_html() aangeroepen.');
        mim_load_template( 'import-export/page-create.php' );
    }

    /**
     * Maak meerdere pagina's aan op basis van de ingevoerde namen.
     */
    public function create_multiple_pages(): void {
        error_log('[ACF_Export_Page_Admin] create_multiple_pages() gestart.');

        if ( ! current_user_can( 'manage_options' ) ) {
            error_log('[ACF_Export_Page_Admin] Gebruiker heeft niet de benodigde rechten.');
            wp_die( __( 'Toegang geweigerd.', 'export-acf-csv' ) );
        }

        if ( ! isset( $_POST['create_pages_nonce'] ) ) {
            error_log('[ACF_Export_Page_Admin] create_pages_nonce ontbreekt in POST.');
            wp_die( __( 'Nonce ontbreekt.', 'export-acf-csv' ) );
        }

        $nonce = sanitize_text_field( $_POST['create_pages_nonce'] );
        if ( ! wp_verify_nonce( $nonce, 'create_pages_action' ) ) {
            error_log('[ACF_Export_Page_Admin] Nonce validatie mislukt. Ontvangen nonce: ' . $nonce);
            wp_die( __( 'Toegang geweigerd of ongeldig nonce.', 'export-acf-csv' ) );
        }

        $page_names_input = sanitize_textarea_field( $_POST['page_names'] ?? '' );
        error_log('[ACF_Export_Page_Admin] Ingevoerde paginanamen: ' . $page_names_input);

        if ( empty( $page_names_input ) ) {
            error_log('[ACF_Export_Page_Admin] Geen paginanamen ingevoerd.');
            wp_die( __( 'Geen paginanamen ingevoerd.', 'export-acf-csv' ) );
        }

        // Verdeel de paginanamen op basis van nieuwe regels of komma's.
        $page_names = preg_split( '/[\r\n,]+/', $page_names_input );
        error_log('[ACF_Export_Page_Admin] Verwerkte paginanamen: ' . print_r( $page_names, true ));
        $created_pages = [];

        foreach ( $page_names as $page_name ) {
            $page_name = trim( $page_name );
            if ( ! empty( $page_name ) ) {
                error_log('[ACF_Export_Page_Admin] Proberen pagina aan te maken: ' . $page_name);
                $new_page_id = wp_insert_post([
                    'post_title'   => $page_name,
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_content' => '',
                ]);
                if ( ! is_wp_error( $new_page_id ) ) {
                    $created_pages[] = $page_name;
                    error_log('[ACF_Export_Page_Admin] Pagina succesvol aangemaakt: ' . $page_name . ' (ID: ' . $new_page_id . ')');
                } else {
                    error_log('[ACF_Export_Page_Admin] Fout bij het aanmaken van pagina: ' . $page_name . '. Error: ' . print_r( $new_page_id, true ));
                }
            }
        }

        if ( ! empty( $created_pages ) ) {
            $message      = sprintf( __( 'De volgende pagina\'s zijn aangemaakt: %s', 'export-acf-csv' ), implode( ', ', $created_pages ) );
            $message_type = 'success';
        } else {
            $message      = __( 'Er zijn geen pagina\'s aangemaakt.', 'export-acf-csv' );
            $message_type = 'error';
        }

        error_log('[ACF_Export_Page_Admin] Resultaat bericht: ' . $message);
        wp_safe_redirect(
            add_query_arg(
                [
                    'create_pages_message' => urlencode( $message ),
                    'message_type'         => $message_type,
                ],
                admin_url( 'admin.php?page=export-acf-csv-pagina' )
            )
        );
        exit;
    }
}