<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Voorkomt directe toegang.
}

class Modern_Image_Manager {
    /**
     * Initialiseert de Modern Image Manager.
     */
    public static function init(): void {
        add_action( 'admin_menu', [ self::class, 'add_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
    }

    /**
     * Voegt het hoofdmenu en de submenu's toe in het WordPress admin dashboard.
     */
    public static function add_admin_menu(): void {
        // Voeg het top-level menu toe.
        add_menu_page(
            __( 'Modern Image Manager', 'modern-image-manager' ),
            __( 'Modern Image', 'modern-image-manager' ),
            'manage_options',
            'modern-image-manager',
            [ self::class, 'mim_render_admin_table_page' ], // Callback voor admin-tabelpagina
            'dashicons-media-document',
            20
        );

        // Verwijder het automatisch gegenereerde duplicaatsubmenu-item.
        remove_submenu_page( 'modern-image-manager', 'modern-image-manager' );

        // Definieer submenu's in een array voor eenvoudiger beheer.
        $submenu_items = [
            [
                'title'     => __( 'Exporteer Media', 'modern-image-manager' ),
                'menu'      => __( 'Exporteren', 'modern-image-manager' ),
                'slug'      => 'export-media',
                'template'  => 'modern-image/export-page.php'
            ],
            [
                'title'     => __( 'Importeer Media', 'modern-image-manager' ),
                'menu'      => __( 'Importeren', 'modern-image-manager' ),
                'slug'      => 'import-media',
                'template'  => 'modern-image/import-page.php'
            ],
            [
                'title'     => __( 'Scan Duplicate Images', 'modern-image-manager' ),
                'menu'      => __( 'Scan Duplicate Images', 'modern-image-manager' ),
                'slug'      => 'scan-duplicate-images',
                'template'  => 'scan-image/scan-duplicate-page.php'
            ],
            [
                'title'     => __( 'Pagina\'s aanmaken', 'modern-image-manager' ),
                'menu'      => __( 'Pagina\'s', 'modern-image-manager' ),
                'slug'      => 'create-pages',
                'template'  => 'import-export/page-create.php'
            ],
            [
                'title'     => __( 'ACF Exporteren', 'modern-image-manager' ),
                'menu'      => __( 'ACF Export', 'modern-image-manager' ),
                'slug'      => 'export-acf-to-csv',
                'callback'  => [ ACF_Export_Admin::class, 'export_page_html' ]
            ],
            [
                'title'     => __( 'ACF Importeren', 'modern-image-manager' ),
                'menu'      => __( 'ACF Import', 'modern-image-manager' ),
                'slug'      => 'import-acf-to-csv',
                'callback'  => [ ACF_Export_Import_Admin::class, 'render_import_page' ]
            ]
        ];

        // Voeg submenu-items toe
        foreach ($submenu_items as $item) {
            if (isset($item['callback'])) {
                add_submenu_page(
                    'modern-image-manager',
                    $item['title'],
                    $item['menu'],
                    'manage_options',
                    $item['slug'],
                    $item['callback']
                );
            } else {
                add_submenu_page(
                    'modern-image-manager',
                    $item['title'],
                    $item['menu'],
                    'manage_options',
                    $item['slug'],
                    function() use ($item) {
                        mim_load_template( $item['template'] );
                    }
                );
            }
        }
    }

    /**
     * Laadt de admin-tabelpagina via een templatebestand.
     */
    public static function mim_render_admin_table_page(): void {
        mim_load_template( 'modern-image/admin-table.php' );
    }

    /**
     * Laadt de benodigde CSS- en JavaScript-assets voor de adminpagina.
     *
     * @param string $hook De huidige adminpagina hook.
     */
    public static function enqueue_assets( string $hook ): void {
        // Controleer of we op een relevante adminpagina zijn
        if ( ! in_array( $hook, [
            'toplevel_page_modern-image-manager',
            'modern-image-manager_page_export-media',
            'modern-image-manager_page_import-media',
            'modern-image-manager_page_scan-duplicate-images',
            'modern-image-manager_page_export-acf-to-csv',
            'modern-image-manager_page_import-acf-to-csv'
        ], true ) ) {
            return;
        }

        // Voeg je CSS/JS-bestanden hier toe
        wp_enqueue_style( 'modern-image-manager-admin', plugin_dir_url( __FILE__ ) . 'assets/admin.css' );
        wp_enqueue_script( 'modern-image-manager-admin', plugin_dir_url( __FILE__ ) . 'assets/admin.js', [ 'jquery' ], null, true );
    }
}

// Initialiseer de plugin
Modern_Image_Manager::init();