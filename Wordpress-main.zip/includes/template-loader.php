<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Voorkomt directe toegang
}

/**
 * Laadt een templatebestand uit de /templates map.
 *
 * @param string $template_name Naam van het templatebestand.
 * @param array  $vars          (Optioneel) Associatieve array met variabelen die in het template beschikbaar komen.
 */
function mim_load_template( string $template_name, array $vars = [] ): void {
    $template_path = MODERN_IMAGE_MANAGER_PATH . 'templates/' . $template_name;

    if ( file_exists( $template_path ) ) {
        extract( $vars );
        include $template_path;
    } else {
        wp_die( sprintf( __('Template niet gevonden: %s', 'modern-image-manager'), esc_html($template_name) ) );
    }
}