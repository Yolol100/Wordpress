<?php
/**
 * Template voor het aanmaken van meerdere pagina's.
 * Beschikbare variabelen (via URL): 
 * - $_GET['create_pages_message']
 * - $_GET['message_type']
 */
$message      = $_GET['create_pages_message'] ?? '';
$message_type = $_GET['message_type'] ?? '';
?>
<div class="wrap export-acf-csv">
	<h1 class="export-acf-csv-title"><?php esc_html_e( 'Pagina\'s aanmaken', 'export-acf-csv' ); ?></h1>

	<?php if ( $message ) : ?>
		<div class="notice notice-<?php echo esc_attr( $message_type ); ?> is-dismissible">
			<p><?php echo esc_html( $message ); ?></p>
		</div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="export-acf-csv-form">
		<?php wp_nonce_field( 'create_pages_action', 'create_pages_nonce' ); ?>
		<input type="hidden" name="action" value="create_multiple_pages">
		<table class="form-table export-acf-csv-table">
			<tr>
				<th class="export-acf-csv-label">
					<label for="page_names"><?php esc_html_e( 'Voer paginanamen in:', 'export-acf-csv' ); ?></label>
				</th>
				<td>
					<textarea name="page_names" id="page_names" rows="5" class="export-acf-csv-textarea" required></textarea>
					<p class="description"><?php esc_html_e( 'Gebruik een nieuwe regel of komma om meerdere paginanamen in te voeren.', 'export-acf-csv' ); ?></p>
				</td>
			</tr>
		</table>
		<?php submit_button( __( 'Aanmaken', 'export-acf-csv' ), 'primary', 'submit', true, [ 'class' => 'button' ] ); ?>
	</form>
</div>