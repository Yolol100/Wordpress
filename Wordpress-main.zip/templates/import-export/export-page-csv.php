<?php
/**
 * Template voor de ACF exportpagina.
 * Variabele beschikbaar: $acf_fields (array met ACF-velden)
 */
?>
<div class="wrap export-acf-csv">
	<h1 class="export-acf-csv-title"><?php esc_html_e( 'Exporteren', 'export-acf-csv' ); ?></h1>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="export-acf-csv-form">
		<?php wp_nonce_field( 'export_acf_csv_action', 'export_acf_csv_nonce' ); ?>
		<input type="hidden" name="action" value="acf_export_csv">
		<table class="form-table export-acf-csv-table">
			<tr>
				<th class="export-acf-csv-label">
					<label for="post_type"><?php esc_html_e( 'Selecteer Post Type:', 'export-acf-csv' ); ?></label>
				</th>
				<td>
					<select name="post_type" id="post_type" class="export-acf-csv-select" required>
						<?php foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) : ?>
							<option value="<?php echo esc_attr( $pt->name ); ?>">
								<?php echo esc_html( $pt->label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th class="export-acf-csv-label">
					<label for="fields"><?php esc_html_e( 'Selecteer ACF Velden:', 'export-acf-csv' ); ?></label>
				</th>
				<td>
					<select multiple name="fields[]" id="fields" class="export-acf-csv-select" required>
						<?php foreach ( $acf_fields as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>">
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th class="export-acf-csv-label">
					<label for="pages"><?php esc_html_e( 'Selecteer Items', 'export-acf-csv' ); ?></label>
				</th>
				<td>
					<select multiple name="pages[]" id="pages" class="export-acf-csv-select" required>
						<?php
						$query = new WP_Query([
							'post_type'      => 'post',
							'post_status'    => 'publish',
							'posts_per_page' => -1,
						]);

						if ( $query->have_posts() ) :
							while ( $query->have_posts() ) :
								$query->the_post();
								?>
								<option value="<?php echo esc_attr( get_the_ID() ); ?>">
									<?php echo esc_html( get_the_title() ); ?>
								</option>
							<?php endwhile;
						else : ?>
							<option value=""><?php esc_html_e( 'Geen pagina\'s gevonden', 'export-acf-csv' ); ?></option>
						<?php endif;
						wp_reset_postdata();
						?>
					</select>
				</td>
			</tr>
		</table>
		<?php submit_button( __( 'Exporteren', 'export-acf-csv' ), 'primary', 'submit', true, [ 'class' => 'button' ] ); ?>
	</form>
</div>