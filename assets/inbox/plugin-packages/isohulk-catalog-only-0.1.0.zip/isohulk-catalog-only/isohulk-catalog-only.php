<?php
/**
 * Plugin Name: ISOHULK Catalogue Only
 * Description: Displays WooCommerce products and prices without allowing customer orders, and provisions the NL 21% VAT rate on initial activation.
 * Version: 0.1.0
 * Requires Plugins: woocommerce
 * Requires PHP: 7.4
 * Author: Webactueel
 * Text Domain: isohulk-catalog-only
 */
declare(strict_types=1);

defined('ABSPATH') || exit;

const ISOHULK_CATALOG_HOST = 'isohulk.conceptwebactueel-6.nl';
const ISOHULK_CATALOG_VERSION = '0.1.0';

function isohulk_catalog_is_target(): bool {
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    return is_string($host) && strtolower($host) === ISOHULK_CATALOG_HOST;
}

function isohulk_catalog_tax_fields(): array {
    return array(
        'woocommerce_calc_taxes' => 'yes',
        'woocommerce_prices_include_tax' => 'no',
        'woocommerce_tax_display_shop' => 'incl',
        'woocommerce_tax_display_cart' => 'incl',
        'woocommerce_tax_based_on' => 'base',
        'woocommerce_default_customer_address' => 'base',
    );
}

/**
 * One-time, staging-host-guarded provisioning. Existing standard tax rates
 * block activation to avoid silently replacing a tax policy. The official
 * WooCommerce REST controller creates the rate; no direct SQL is used.
 */
function isohulk_catalog_activate(): void {
    if (!isohulk_catalog_is_target()) {
        throw new RuntimeException('This site-specific catalogue plugin is restricted to the ISOHULK concept hostname.');
    }
    if (!class_exists('WooCommerce') || !class_exists('WC_Tax') || !function_exists('rest_do_request')) {
        throw new RuntimeException('WooCommerce and its REST API are required.');
    }

    $already = (int) get_option('isohulk_catalog_tax_rate_id', 0);
    if ($already > 0) {
        $get = new WP_REST_Request('GET', '/wc/v3/taxes/' . $already);
        $current = rest_do_request($get);
        $value = $current instanceof WP_REST_Response ? $current->get_data() : array();
        if (is_array($value) && ($value['country'] ?? '') === 'NL' && (string) ($value['rate'] ?? '') === '21.0000') {
            return;
        }
        throw new RuntimeException('Existing ISOHULK tax bootstrap identifier no longer matches the provider tax rate.');
    }

    $existing = WC_Tax::get_rates_for_tax_class('');
    if (!is_array($existing) || count($existing) !== 0) {
        throw new RuntimeException('Standard VAT table is not empty; refusing to replace or duplicate existing tax rates.');
    }

    $previous = array();
    foreach (isohulk_catalog_tax_fields() as $key => $value) {
        $previous[$key] = get_option($key, null);
    }
    $backup = array('state' => 'prepared', 'before' => $previous, 'desired' => isohulk_catalog_tax_fields());
    update_option('isohulk_catalog_tax_backup', $backup, false);

    $create = new WP_REST_Request('POST', '/wc/v3/taxes');
    $create->set_body_params(array(
        'country' => 'NL',
        'state' => '',
        'rate' => '21.0000',
        'name' => 'BTW 21%',
        'priority' => 1,
        'compound' => false,
        'shipping' => true,
        'order' => 1,
        'class' => 'standard',
    ));
    $response = rest_do_request($create);
    $data = $response instanceof WP_REST_Response ? $response->get_data() : array();
    if (!($response instanceof WP_REST_Response) || $response->get_status() !== 201 ||
        !is_array($data) || (int) ($data['id'] ?? 0) < 1 ||
        ($data['country'] ?? '') !== 'NL' || (string) ($data['rate'] ?? '') !== '21.0000') {
        throw new RuntimeException('WooCommerce rejected the standard NL 21% VAT rate. Original settings were not changed.');
    }

    $created_id = (int) $data['id'];
    $backup['state'] = 'rate_created';
    $backup['rate_id'] = $created_id;
    update_option('isohulk_catalog_tax_backup', $backup, false);

    try {
        foreach (isohulk_catalog_tax_fields() as $key => $value) {
            update_option($key, $value);
            if (get_option($key) !== $value) {
                throw new RuntimeException('Tax option readback mismatch: ' . $key);
            }
        }
        $check = rest_do_request(new WP_REST_Request('GET', '/wc/v3/taxes/' . $created_id));
        $verified = $check instanceof WP_REST_Response ? $check->get_data() : array();
        if (!is_array($verified) || ($verified['country'] ?? '') !== 'NL' ||
            (string) ($verified['rate'] ?? '') !== '21.0000') {
            throw new RuntimeException('Tax rate readback mismatch after creation.');
        }
        update_option('isohulk_catalog_tax_rate_id', $created_id, false);
        $backup['state'] = 'configured';
        update_option('isohulk_catalog_tax_backup', $backup, false);
    } catch (Throwable $error) {
        foreach ($previous as $key => $value) {
            update_option($key, $value);
        }
        $delete = new WP_REST_Request('DELETE', '/wc/v3/taxes/' . $created_id);
        $delete->set_param('force', true);
        $removed = rest_do_request($delete);
        $backup['state'] = 'failed_restore_attempted';
        $backup['restore_verified'] = ($removed instanceof WP_REST_Response && !$removed->is_error());
        update_option('isohulk_catalog_tax_backup', $backup, false);
        throw new RuntimeException('Tax configuration failed; provider rate/settings restoration attempted. ' . $error->getMessage());
    }
}
register_activation_hook(__FILE__, 'isohulk_catalog_activate');

/** Catalogue-only, all roles, independent of active theme or WooCommerce blocks. */
function isohulk_catalog_boot(): void {
    if (!isohulk_catalog_is_target() || !class_exists('WooCommerce')) {
        return;
    }

    // Commerce API and classic/template use the same core purchasability checks.
    add_filter('woocommerce_is_purchasable', '__return_false', PHP_INT_MAX, 2);
    add_filter('woocommerce_variation_is_purchasable', '__return_false', PHP_INT_MAX, 2);
    add_filter('woocommerce_add_to_cart_validation', '__return_false', PHP_INT_MAX, 6);

    // Both classic checkout and stale existing cart sessions are blocked.
    add_action('woocommerce_checkout_process', 'isohulk_catalog_reject_checkout', PHP_INT_MAX);
    add_action('woocommerce_check_cart_items', 'isohulk_catalog_reject_checkout', PHP_INT_MAX);

    // WooCommerce Store API is blocked server-side, including direct POST links.
    add_filter('rest_pre_dispatch', 'isohulk_catalog_block_store_api', PHP_INT_MAX, 3);

    // Present existing prices; never invent missing commercial data.
    add_filter('woocommerce_get_price_html', 'isohulk_catalog_price_html', 20, 2);
    add_filter('woocommerce_get_availability_text', '__return_empty_string', 20, 2);

    // Keep variation selectors and their prices, but remove the buy action.
    add_action('wp', 'isohulk_catalog_remove_buy_buttons', 20);
    add_action('wp_enqueue_scripts', 'isohulk_catalog_styles', 20);
    add_action('template_redirect', 'isohulk_catalog_no_cart_pages', 1);
}
add_action('plugins_loaded', 'isohulk_catalog_boot', 30);

function isohulk_catalog_reject_checkout(): void {
    if (function_exists('wc_add_notice')) {
        wc_add_notice('Ordering is disabled. This website is a product catalogue.', 'error');
    }
}

function isohulk_catalog_block_store_api($result, $server, $request) {
    if (!isohulk_catalog_is_target() || !is_object($request) ||
        !method_exists($request, 'get_method') || !method_exists($request, 'get_route')) {
        return $result;
    }
    $method = strtoupper((string) $request->get_method());
    $route = (string) $request->get_route();
    if (in_array($method, array('POST', 'PUT', 'PATCH'), true) &&
        preg_match('~^/wc/store(?:/v[0-9]+)?/(?:cart/add-item|checkout)(?:/|$)~', $route)) {
        return new WP_Error('isohulk_catalog_only', 'Purchases are disabled on this product catalogue.', array('status' => 403));
    }
    return $result;
}

function isohulk_catalog_price_html($price, $product): string {
    return is_string($price) && $price !== '' ? $price : '<span class="price-on-request">Price on request</span>';
}

function isohulk_catalog_remove_buy_buttons(): void {
    remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
    remove_action('woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20);
}

function isohulk_catalog_no_cart_pages(): void {
    if (!function_exists('is_cart') || !function_exists('is_checkout') || is_admin()) {
        return;
    }
    if (is_cart() || is_checkout()) {
        $shop = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '';
        wp_safe_redirect(is_string($shop) && $shop !== '' ? $shop : home_url('/'), 302);
        exit;
    }
}

function isohulk_catalog_styles(): void {
    wp_register_style('isohulk-catalog-only', false, array(), ISOHULK_CATALOG_VERSION);
    wp_enqueue_style('isohulk-catalog-only');
    wp_add_inline_style('isohulk-catalog-only',
        '.single_add_to_cart_button,.add_to_cart_button,.ajax_add_to_cart,' .
        '.wc-block-components-product-button,.wc-block-grid__product-add-to-cart,' .
        '.wp-block-woocommerce-product-button{display:none!important;}');
}
